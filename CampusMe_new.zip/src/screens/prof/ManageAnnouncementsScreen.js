// Placeholder for ManageAnnouncements - list prof announcements
import React from 'react';
import { View, Text } from 'react-native';
export default function ManageAnnouncementsScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Gestion Annonces Prof (TODO: fetch prof announcements, CRUD)</Text>
    </View>
  );
}

