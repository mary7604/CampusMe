// Placeholder for ManageGrades
import React from 'react';
import { View, Text } from 'react-native';
export default function ManageGradesScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Gestion Notes Prof (TODO: fetch prof grades, CRUD)</Text>
    </View>
  );
}

